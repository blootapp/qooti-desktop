// qooti popup script

const statusDot  = document.getElementById('status-dot')
const statusText = document.getElementById('status-text')
const versionEl  = document.getElementById('footer-version')

// ─── Connection status ───────────────────────────────────────────

chrome.runtime.sendMessage({ action: 'get-status' }, res => {
  if (res?.connected) {
    statusDot.classList.add('status-dot--on')
    statusText.textContent = 'Connected'
    if (res.version) versionEl.textContent = `Desktop v${res.version}`
  } else {
    statusDot.classList.add('status-dot--off')
    statusText.textContent = 'qooti not running'
  }
})

// ─── Collection picker toggle ────────────────────────────────────

let pickerEnabled = true
const pickerToggleEl = document.getElementById('picker-toggle')

chrome.storage.sync.get('showPicker', res => {
  pickerEnabled = res.showPicker !== false
  pickerToggleEl.classList.toggle('toggle-switch--on', pickerEnabled)
})

document.getElementById('picker-toggle-row').addEventListener('click', () => {
  pickerEnabled = !pickerEnabled
  chrome.storage.sync.set({ showPicker: pickerEnabled })
  pickerToggleEl.classList.toggle('toggle-switch--on', pickerEnabled)
})

// ─── Download panel toggle ───────────────────────────────────────

let panelEnabled = true
const panelToggleEl = document.getElementById('panel-toggle')

chrome.storage.sync.get('showDownloadPanel', res => {
  panelEnabled = res.showDownloadPanel !== false
  panelToggleEl.classList.toggle('toggle-switch--on', panelEnabled)
})

document.getElementById('panel-toggle-row').addEventListener('click', () => {
  panelEnabled = !panelEnabled
  chrome.storage.sync.set({ showDownloadPanel: panelEnabled })
  panelToggleEl.classList.toggle('toggle-switch--on', panelEnabled)
  chrome.runtime.sendMessage({
    action: 'set-pref',
    key: 'show_download_toast',
    value: panelEnabled ? 'true' : 'false',
  })
})

// ─── Disconnect ──────────────────────────────────────────────────

document.getElementById('btn-disconnect').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'disconnect' }, () => {
    statusDot.className = 'status-dot status-dot--off'
    statusText.textContent = 'Disconnected'
    document.getElementById('btn-disconnect').textContent = 'Reconnect'
    document.getElementById('btn-disconnect').addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'get-status' }, () => window.close())
    }, { once: true })
  })
})
